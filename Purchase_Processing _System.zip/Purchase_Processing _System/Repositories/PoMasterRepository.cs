﻿using Microsoft.EntityFrameworkCore;
using Purchase_Processing__System.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Purchase_Processing__System.Repositories
{
    public class PoMasterRepository : IPostAsyncRepository
    {
        private readonly saiContext _context;

        public PoMasterRepository(saiContext context)
        {
            _context = context;
        }

        public async Task AddPostMan(Pomaster pomaster)
        {
            await _context.Pomasters.AddAsync(pomaster);
            await _context.SaveChangesAsync();
        }

        public async Task DeletePomaster(int id)
        {
            var pomaster = await _context.Pomasters.FindAsync(id);
            if (pomaster != null)
            {
                _context.Pomasters.Remove(pomaster);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<Pomaster>> GetAll()
        {
            return await _context.Pomasters.ToListAsync();
        }

        public async Task<Pomaster> GetPomaster(int id)
        {
            return await _context.Pomasters.FindAsync(id);
        }

        public async Task UpdatePomaster(Pomaster pomaster)
        {
            _context.Pomasters.Update(pomaster);
            await _context.SaveChangesAsync();
            
            
        }
    }
}
