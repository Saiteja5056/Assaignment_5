﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using Purchase_Processing__System.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Purchase_Processing__System.Repositories
{
    public class SupplierRepository : IAsyncSupplierRepository
    {
        private readonly saiContext context;

        public SupplierRepository(saiContext context)
        {
            context = context;
        }

        public async Task AddSupplierAsync(Supplier supplier)
        {

            

            context.Suppliers.Add(supplier);
            await context.SaveChangesAsync();
        }

        public async Task DeleteSupplierAsync(int id)
        {
            var supplier = await context.Suppliers.FindAsync(id);
            if (supplier != null)
            {
                context.Suppliers.Remove(supplier);
                await context.SaveChangesAsync();
            }
        }

        public async Task<List<Supplier>> GetAllSuppliersAsync()
        {
            return await context.Suppliers.ToListAsync();
        }

        public async Task<Supplier> GetSupplierAsyncId(int id)
        {
            return await context.Suppliers.FindAsync(id);
        }

        public async Task UpdateSupplierAsync(Supplier supplier)
        {
                context.Suppliers.Update(supplier);
                await context.SaveChangesAsync();          
        }
    }
}
