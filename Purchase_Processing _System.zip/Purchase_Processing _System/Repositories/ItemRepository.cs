﻿using Microsoft.EntityFrameworkCore;
using Purchase_Processing__System.Entities;

namespace Purchase_Processing__System.Repositories
{
    public class ItemRepository : IAsyncItemRepository
    {
        private readonly saiContext context;

        public ItemRepository(saiContext context)
        {
            context = context;
        }

        public async Task AddItem(Item item)
        {
           await context.Items.AddAsync(item);
            await context.SaveChangesAsync();
        }

        public async Task DeleteItem(int id)
        {
            var item = context.Items.Find(id);
              context.Items.Remove(item);
            await context.SaveChangesAsync();
        }

        public async Task<List<Item>> GetAllItems()
        {
           return await context.Items.ToListAsync();
        }

        public async Task<Item> GetItem(int id)
        {
           var item=context.Items.FindAsync(id);
            return await (item);

        }

        public async Task UpdateItem(Item item)
        {
           context.Items.Update(item);
            await context.SaveChangesAsync();
        }
    }
}
