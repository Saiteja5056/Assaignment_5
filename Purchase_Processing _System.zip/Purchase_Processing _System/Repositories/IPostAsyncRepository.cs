﻿using Purchase_Processing__System.Entities;

namespace Purchase_Processing__System.Repositories
{
    public interface IPostAsyncRepository
    {
        Task AddPostMan(Pomaster pomaster);
        Task<List<Pomaster>> GetAll();
        Task UpdatePomaster(Pomaster pomaster);
        Task DeletePomaster(int id);
        Task<Pomaster> GetPomaster(int id);
    }
}
