﻿using Purchase_Processing__System.Entities;

namespace Purchase_Processing__System.Repositories
{
    public interface IAsyncItemRepository
    {
        Task AddItem(Item item);
        Task<List<Item>> GetAllItems();
        Task UpdateItem(Item item);
        Task DeleteItem(int id);
        Task<Item> GetItem(int id);
    }
}
