﻿using Purchase_Processing__System.Entities;

namespace Purchase_Processing__System.Repositories
{
    public interface IAsyncSupplierRepository
    {
        Task AddSupplierAsync(Supplier supplier);
        Task<List<Supplier>> GetAllSuppliersAsync();
        Task UpdateSupplierAsync(Supplier supplier);
        Task DeleteSupplierAsync(int id);
        Task<Supplier> GetSupplierAsyncId(int id);

    }
}
