﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Purchase_Processing__System.Entities
{
    public class Pomaster
    {
        [Key]
        public int id { get; set; }

        public DateTime? PoDate { get; set; }

        [ForeignKey(nameof(Item))]
        public int? Itemid { get; set; }

        public int? Qty { get; set; }

        [ForeignKey(nameof(Supplier))]
        public int? Suplid{ get; set; }

        // Navigation properties
        public Item Item { get; set; }
        public Supplier Supplier { get; set; }
    }
}
