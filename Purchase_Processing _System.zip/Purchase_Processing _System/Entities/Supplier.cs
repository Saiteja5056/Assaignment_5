﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Purchase_Processing__System.Entities
{
    public class Supplier
    {
        [Key]
        public int Suplid { get; set; }
        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string? SuplName { get; set; }
        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string? SuplAddr { get; set; }
    }
}
