﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Emit;

namespace Purchase_Processing__System.Entities
{
    public class Item
    {
        [Key]
        public int Itemid { get; set; }

        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string? ItDesc { get; set; }
        [Column(TypeName = "varchar")]
        [StringLength(14)]
        public int? ItRate { get; set; }

    }
}
