﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;

namespace Purchase_Processing__System.Entities
{
    public class saiContext :DbContext
    {
        private IConfiguration configuration;
        public saiContext()
        {
            this.configuration = configuration;
        }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Item> Items { get; set; }  
        public DbSet<Pomaster> Pomasters { get; set; }  
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=LAPTOP-7592U22E\\SQLEXPRESS01;Initial Catalog=PODb;Integrated Security=True;Trust Server Certificate=True");

        }

    }
}
