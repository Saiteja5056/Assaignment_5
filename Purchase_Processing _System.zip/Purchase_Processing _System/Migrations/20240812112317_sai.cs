﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Purchase_Processing__System.Migrations
{
    /// <inheritdoc />
    public partial class sai : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Items",
                columns: table => new
                {
                    Itemid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ItDesc = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
                    ItRate = table.Column<string>(type: "varchar(14)", maxLength: 14, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Items", x => x.Itemid);
                });

            migrationBuilder.CreateTable(
                name: "Suppliers",
                columns: table => new
                {
                    Suplid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SuplName = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
                    SuplAddr = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Suppliers", x => x.Suplid);
                });

            migrationBuilder.CreateTable(
                name: "Pomasters",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PoDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Itemid = table.Column<int>(type: "int", nullable: false),
                    Qty = table.Column<int>(type: "int", nullable: false),
                    Suplid = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pomasters", x => x.id);
                    table.ForeignKey(
                        name: "FK_Pomasters_Items_Itemid",
                        column: x => x.Itemid,
                        principalTable: "Items",
                        principalColumn: "Itemid",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Pomasters_Suppliers_Suplid",
                        column: x => x.Suplid,
                        principalTable: "Suppliers",
                        principalColumn: "Suplid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Pomasters_Itemid",
                table: "Pomasters",
                column: "Itemid");

            migrationBuilder.CreateIndex(
                name: "IX_Pomasters_Suplid",
                table: "Pomasters",
                column: "Suplid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Pomasters");

            migrationBuilder.DropTable(
                name: "Items");

            migrationBuilder.DropTable(
                name: "Suppliers");
        }
    }
}
