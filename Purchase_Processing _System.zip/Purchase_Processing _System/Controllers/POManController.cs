﻿using Microsoft.AspNetCore.Mvc;
using Purchase_Processing__System.Entities;
using Purchase_Processing__System.Repositories;

namespace Purchase_Processing__System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class POManController : Controller
    {
        private readonly IPostAsyncRepository asyncitemRepository;
        public POManController(IPostAsyncRepository asyncitemRepository)
        {
            this.asyncitemRepository = asyncitemRepository;
        }
        [HttpGet, Route("GetallSuppliers")]
        public async Task<IActionResult> Getall()
        {
           return Ok( asyncitemRepository.GetAll());
        }
        [HttpGet, Route("GetallSuppliersById")]
        public async Task<IActionResult> Get(int id)
        {
            return Ok( await  asyncitemRepository.GetPomaster(id));
           
            
        }
        [HttpPost, Route("AddSupplier")]
        public async Task<IActionResult> Add(Pomaster pomaster)
        {
           return Ok( asyncitemRepository.AddPostMan(pomaster));
        }
        [HttpPut, Route("UpdateSupplier")]
        public async Task<IActionResult> Update(Pomaster pomaster)
        {
            return Ok(asyncitemRepository.UpdatePomaster(pomaster));

        }
        [HttpDelete, Route("DeleteSupplier")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(asyncitemRepository.DeletePomaster(id));

        }
    }
}
