﻿using Microsoft.AspNetCore.Mvc;
using Purchase_Processing__System.Entities;
using Purchase_Processing__System.Repositories;

namespace Purchase_Processing__System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : Controller
    {
        private readonly IAsyncItemRepository asyncItemRepository;
        public ItemController(IAsyncItemRepository asyncItemRepository)
        {
            this.asyncItemRepository = asyncItemRepository;
        }
        [HttpGet, Route("Getallitems")]
        public async  Task<IActionResult> Getall()
        {
            return Ok(asyncItemRepository.GetAllItems());
        }
        [HttpGet, Route("GetallitemsById")]
        public async Task<IActionResult> Get(int id)
        {
            return Ok(asyncItemRepository.GetItem(id));
        }
        [HttpPost, Route("Additem")]
        public async Task<IActionResult> Add(Item item)
        {
            asyncItemRepository.AddItem(item);
            return Ok();
        }
        [HttpPut, Route("Updateitem")]
        public async Task<IActionResult> Update(Item item)
        {
           await asyncItemRepository.UpdateItem(item);
            return Ok();
        }
        [HttpDelete, Route("Deleteitem")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            await asyncItemRepository.DeleteItem(id);

            return Ok();

        }
    }
}
