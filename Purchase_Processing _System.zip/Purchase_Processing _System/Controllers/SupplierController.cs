﻿using Microsoft.AspNetCore.Mvc;
using Purchase_Processing__System.Entities;
using Purchase_Processing__System.Repositories;

namespace Purchase_Processing__System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : Controller
    {
       private readonly IAsyncSupplierRepository asyncSupplierRepository;
        public SupplierController(IAsyncSupplierRepository asyncSupplierRepository)
        {
            this.asyncSupplierRepository = asyncSupplierRepository;
        }
        [HttpGet,Route("GetallSuppliers")]
        public async Task<IActionResult> Getall()
        {
            return Ok(await asyncSupplierRepository.GetAllSuppliersAsync());        
        }
        [HttpGet, Route("GetallSuppliersById")]
        public async Task<IActionResult> Get(int id)
        {
            return Ok(await asyncSupplierRepository.GetSupplierAsyncId(id));
        }
        [HttpPost,Route("AddSupplier")]
        public async Task<IActionResult> Add(Supplier supplier)
        {

            if (supplier == null) return BadRequest("Supplier is null");

            await asyncSupplierRepository.AddSupplierAsync(supplier);
            return Ok();
        }
        [HttpPut,Route("UpdateSupplier")]
        public async Task<IActionResult> Update(Supplier supplier)
        {
            await asyncSupplierRepository.UpdateSupplierAsync(supplier);
            return Ok();


        }
        [HttpDelete,Route("DeleteSupplier")]
        public async Task<IActionResult> Delete(int id)
        {
           await  asyncSupplierRepository.DeleteSupplierAsync(id);
            return Ok();
        }
    }
}
